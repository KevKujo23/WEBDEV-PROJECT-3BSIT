package com.uapasia.web;

import com.uapasia.model.Professor;
import com.uapasia.model.User;
import com.uapasia.repo.ContextStore;
import com.uapasia.util.CookieUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet(name = "NewProfessorServlet", urlPatterns = {"/do.newprofessors"})
public class NewProfessorServlet extends HttpServlet {

    private void renderForm(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String ctx = request.getContextPath();
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html><head><meta charset='UTF-8'><title>Add Professor</title>");
            out.println("<link rel=\"stylesheet\" href=\"css/styles.css\">");
            out.println("</head><body class='panel'>");

            out.println("<nav class='top-nav'>"
                    + "<a href='" + ctx + "/'>Home</a>"
                    + "<a href='" + ctx + "/do.professors'>Browse Professors</a>"
                    + "<a href='" + ctx + "/do.newprofessors'>Add Professor</a>"
                    + "<a href='" + ctx + "/do.newratings'>Add Rating</a>"
                    + "<a href='" + ctx + "/do.logout'>Logout</a>"
                    + "</nav>");

            out.println("<div class='panel-container'>");
            out.println("<h2>Add Professor</h2>");

            out.println("<form method='post' action='" + ctx + "/professors/new'>"
                    + "<div class='form-group'><label>Name"
                    + "<input name='name' required></label></div>"
                    + "<div class='form-group'><label>Department"
                    + "<input name='dept' required></label></div>"
                    + "<button type='submit'>Save</button>"
                    + "</form>");

            out.println("<p class='note'><a href='" + ctx + "/professors'>Back to list</a></p>");
            out.println("</div></body></html>");
        }
    }

    @Override protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        renderForm(request, response);
    }

    @Override protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        User user = (User) request.getSession().getAttribute("user");
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login?status=unauthorized");
            return;
        }
        String name = request.getParameter("name");
        String dept = request.getParameter("dept");
        if (name == null || name.isBlank() || dept == null || dept.isBlank()) {
            response.sendRedirect(request.getContextPath() + "/professors/new?status=invalid");
            return;
        }
        List<Professor> list = ContextStore.profs(getServletContext());
        list.add(new Professor(name.trim(), dept.trim(), user.getUsername()));
        response.addCookie(CookieUtils.make("last_prof", name.trim(), 30 * 24 * 60 * 60));
        response.sendRedirect(request.getContextPath() + "/professors?status=added");
    }
}
