package com.uapasia.web;

import com.uapasia.model.Professor;
import com.uapasia.repo.ContextStore;
import com.uapasia.util.CookieUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet(name = "ProfessorsServlet", urlPatterns = {"/do.professors"})
public class ProfessorsServlet extends HttpServlet {

    @Override protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Professor> profs = ContextStore.profs(getServletContext());
        String ctx = request.getContextPath();
        String last = CookieUtils.get(request, "last_prof");

        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html><head><meta charset='UTF-8'><title>Professors</title>");
            out.println("<link rel=\"stylesheet\" href=\"css/styles.css\">");
            out.println("</head><body class='panel'>");

            out.println("<nav class='top-nav'>"
                    + "<a href='" + ctx + "/'>Home</a>"
                    + "<a href='" + ctx + "/do.professors'>Browse Professors</a>"
                    + "<a href='" + ctx + "/do.newprofessors'>Add Professor</a>"
                    + "<a href='" + ctx + "/do.ratings'>Add Rating</a>"
                    + "<a href='" + ctx + "/do.logout'>Logout</a>"
                    + "</nav>");

            out.println("<div class='panel-container'>");
            out.println("<h2>Professors</h2>");

            if (profs.isEmpty()) {
                out.println("<p>No professors yet.</p>");
            } else {
                out.println("<table>");
                out.println("<thead><tr><th>Name</th><th>Department</th></tr></thead><tbody>");
                for (Professor p : profs) {
                    out.println("<tr>"
                            + "<td><a href='" + ctx + "/ratings/new?prof=" + p.getName() + "'>"
                            + p.getName() + "</a></td>"
                            + "<td>" + p.getDept() + "</td>"
                            + "</tr>");
                }
                out.println("</tbody></table>");
            }

            out.println("<p class='note'>Last visited professor: " + (last == null ? "—" : last) + "</p>");
            out.println("</div></body></html>");
        }
    }
}
