package com.uapasia.web;

import com.uapasia.model.Rating;
import com.uapasia.model.User;
import com.uapasia.repo.ContextStore;
import com.uapasia.util.CookieUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet(name = "NewRatingServlet", urlPatterns = {"/do.ratings"})
public class NewRatingServlet extends HttpServlet {

    private static String safe(String s){
        if (s == null) return "";
        return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")
                .replace("\"","&quot;").replace("'","&#39;");
    }

    private void renderForm(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String ctx = request.getContextPath();
        String prof = request.getParameter("prof");
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html><head><meta charset='UTF-8'><title>Add Rating</title>");
            out.println("<link rel=\"stylesheet\" href=\"css/styles.css\">");
            out.println("</head><body class='panel'>");

            out.println("<nav class='top-nav'>"
                    + "<a href='" + ctx + "/'>Home</a>"
                    + "<a href='" + ctx + "/do.professors'>Browse Professors</a>"
                    + "<a href='" + ctx + "/do.newprofessors'>Add Professor</a>"
                    + "<a href='" + ctx + "/do.newratings'>Add Rating</a>"
                    + "<a href='" + ctx + "/do.logout'>Logout</a>"
                    + "</nav>");

            out.println("<div class='panel-container'>");
            out.println("<h2>Add Rating</h2>");

            out.println("<form method='post' action='" + ctx + "/ratings/new'>"
                    + "<div class='form-group'><label>Professor"
                    + "<input name='prof' value='" + safe(prof) + "' required></label></div>"
                    + "<div class='form-group'><label>Score (1-5)"
                    + "<input type='number' name='score' min='1' max='5' required></label></div>"
                    + "<div class='form-group'><label>Comment"
                    + "<textarea name='comment' rows='3'></textarea></label></div>"
                    + "<button type='submit'>Save</button>"
                    + "</form>");

            out.println("<p class='note'><a href='" + ctx + "/professors'>Back to list</a></p>");
            out.println("</div></body></html>");
        }
    }

    @Override protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        renderForm(request, response);
    }

    @Override protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        User user = (User) request.getSession().getAttribute("user");
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login?status=unauthorized");
            return;
        }
        String prof = request.getParameter("prof");
        String scoreStr = request.getParameter("score");
        String comment = request.getParameter("comment");
        int score = 0;
        try { score = Integer.parseInt(scoreStr); } catch (Exception ignored) {}

        if (prof == null || prof.isBlank() || score < 1 || score > 5) {
            response.sendRedirect(request.getContextPath() + "/ratings/new?status=invalid&prof=" + (prof == null ? "" : prof));
            return;
        }

        List<Rating> rs = ContextStore.ratings(getServletContext());
        rs.add(new Rating(prof.trim(), score, comment == null ? "" : comment.trim(), user.getUsername()));
        response.addCookie(CookieUtils.make("last_prof", prof.trim(), 30 * 24 * 60 * 60));
        response.sendRedirect(request.getContextPath() + "/professors?status=rating_added");
    }
}
