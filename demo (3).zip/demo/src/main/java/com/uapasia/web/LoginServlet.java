package com.uapasia.web;

import com.uapasia.model.User;
import com.uapasia.repo.ContextStore;
import com.uapasia.util.CookieUtils;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet(name = "LoginServlet", urlPatterns = {"/do.login"})
public class LoginServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        if ("POST".equalsIgnoreCase(request.getMethod())) {
            String u = request.getParameter("username");
            String p = request.getParameter("password");
            String remember = request.getParameter("remember");

            List<User> users = ContextStore.users(getServletContext());
            User found = users.stream()
                    .filter(x -> x.getUsername().equals(u) && x.getPassword().equals(p))
                    .findFirst().orElse(null);

            if (found == null) {
                response.sendRedirect(request.getContextPath() + "/login?status=invalid");
                return;
            }

            HttpSession s = request.getSession(true);
            s.setAttribute("user", found);
            s.setMaxInactiveInterval(15 * 60); // 15 minutes

            if ("on".equals(remember)) {
                response.addCookie(CookieUtils.make("remember_username", u, 7 * 24 * 60 * 60));
            }
            response.sendRedirect(request.getContextPath() + "/?status=logged_in");
            return;
        }

        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String ctx = request.getContextPath();
            String status = request.getParameter("status");
            String msg = "";
            if ("invalid".equals(status)) msg = "<p style='color:red'>Invalid credentials.</p>";
            if ("registered".equals(status)) msg = "<p style='color:green'>Registered successfully. Please login.</p>";
            out.println("<!DOCTYPE html>");
            out.println("<html><head><meta charset='UTF-8'><title>Login</title>");
            out.println("<link rel=\"stylesheet\" href=\"css/styles.css\">");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Login</h1>");
            out.println(msg);
            out.println("<form method='post' action='" + ctx + "/login'>");
            out.println("<label>Username: <input name='username' required></label><br>");
            out.println("<label>Password: <input type='password' name='password' minlength='5' required></label><br>");
            out.println("<label><input type='checkbox' name='remember'> Remember me</label><br>");
            out.println("<button type='submit'>Login</button>");
            out.println("</form>");
            out.println("<p><a href='" + ctx + "/register'>Register</a> | <a href='" + ctx + "/'>Home</a></p>");
            out.println("</body></html>");
        }
    }

    @Override protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException { processRequest(req, resp); }
    @Override protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException { processRequest(req, resp); }
}
