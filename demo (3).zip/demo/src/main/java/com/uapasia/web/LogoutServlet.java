package com.uapasia.web;

import com.uapasia.util.CookieUtils;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet(name = "LogoutServlet", urlPatterns = {"/do.logout"})
public class LogoutServlet extends HttpServlet {
    @Override protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession s = request.getSession(false);
        if (s != null) s.invalidate();
        CookieUtils.clear(response, "remember_username");
        response.sendRedirect(request.getContextPath() + "/?status=logged_out");
    }
}
