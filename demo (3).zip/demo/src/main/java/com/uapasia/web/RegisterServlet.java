/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.uapasia.web;

import com.uapasia.model.User;
import com.uapasia.repo.ContextStore;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet(name = "RegisterServlet", urlPatterns = {"/do.register"})
public class RegisterServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        if ("POST".equalsIgnoreCase(request.getMethod())) {
            String u = request.getParameter("username");
            String p = request.getParameter("password");
            String c = request.getParameter("confirm");

            boolean ok = (u != null && !u.isBlank() && p != null && p.length() >= 5 && p.equals(c));
            if (ok) {
                List<User> users = ContextStore.users(getServletContext());
                boolean exists = users.stream().anyMatch(x -> x.getUsername().equalsIgnoreCase(u));
                ok = !exists;
                if (ok) users.add(new User(u, p, "student"));
            }

            if (ok) {
                response.sendRedirect(request.getContextPath() + "/login?status=registered");
                return;
            } else {
                response.sendRedirect(request.getContextPath() + "/register?status=invalid");
                return;
            }
        }

        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String ctx = request.getContextPath();
            String msg = "invalid".equals(request.getParameter("status")) ? "<p style='color:red'>Invalid or duplicate inputs.</p>" : "";
            out.println("<!DOCTYPE html>");
            out.println("<html><head><meta charset='UTF-8'><title>Register</title></head><body>");
            out.println("<h1>Register</h1>");
            out.println(msg);
            out.println("<form method='post' action='" + ctx + "/register'>");
            out.println("<label>Username: <input name='username' required></label><br>");
            out.println("<label>Password: <input type='password' name='password' minlength='5' required></label><br>");
            out.println("<label>Confirm:  <input type='password' name='confirm' minlength='5' required></label><br>");
            out.println("<button type='submit'>Create account</button>");
            out.println("</form>");
            out.println("<p><a href='" + ctx + "/login'>Login</a> | <a href='" + ctx + "/'>Home</a></p>");
            out.println("</body></html>");
        }
    }

    @Override protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException { processRequest(req, resp); }
    @Override protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException { processRequest(req, resp); }
}
