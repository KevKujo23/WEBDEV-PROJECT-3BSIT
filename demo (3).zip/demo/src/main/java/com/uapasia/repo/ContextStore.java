package com.uapasia.repo;

import com.uapasia.model.*;
import javax.servlet.ServletContext;
import java.util.*;

public class ContextStore {
    public static final String USERS="users", PROFESSORS="professors", RATINGS="ratings";

    @SuppressWarnings("unchecked")
    public static List<User> users(ServletContext c){ return (List<User>) c.getAttribute(USERS); }
    public static List<Professor> profs(ServletContext c){ return (List<Professor>) c.getAttribute(PROFESSORS); }
    public static List<Rating> ratings(ServletContext c){ return (List<Rating>) c.getAttribute(RATINGS); }

    public static void init(ServletContext ctx){
        if(ctx.getAttribute(USERS)==null) ctx.setAttribute(USERS, new ArrayList<User>());
        if(ctx.getAttribute(PROFESSORS)==null) ctx.setAttribute(PROFESSORS, new ArrayList<Professor>());
        if(ctx.getAttribute(RATINGS)==null) ctx.setAttribute(RATINGS, new ArrayList<Rating>());
        // Hardcoded admins (adjust as you confirm)
        List<User> u = users(ctx);
        if (u.stream().noneMatch(x -> x.getUsername().equals("alexandervelo"))) u.add(new User("alexandervelo","12345","admin"));
        if (u.stream().noneMatch(x -> x.getUsername().equals("kevinlapuz")))   u.add(new User("kevinlapuz","12345","admin"));
        if (u.stream().noneMatch(x -> x.getUsername().equals("aldrinpaltao"))) u.add(new User("aldrinpaltao","12345","admin"));
    }
}

