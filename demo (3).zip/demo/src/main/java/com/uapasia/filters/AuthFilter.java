package com.uapasia.filters;

import com.uapasia.model.User;
import javax.servlet.annotation.WebFilter;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

@WebFilter(urlPatterns={"/professors/new","/ratings/new"})
public class AuthFilter implements Filter {
    @Override public void doFilter(ServletRequest rq, ServletResponse rs, FilterChain fc) throws IOException, ServletException {
        HttpServletRequest req=(HttpServletRequest)rq; HttpServletResponse resp=(HttpServletResponse)rs;
        HttpSession s = req.getSession(false);
        if(s==null || s.getAttribute("user")==null){ resp.sendRedirect(req.getContextPath()+"/login"); return; }
        fc.doFilter(rq, rs);
    }
}
