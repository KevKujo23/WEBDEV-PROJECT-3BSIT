package com.uapasia.model;

public class Professor {

    private String name, dept, submittedBy;

    public Professor(){

    }

    public Professor(String n,String d,String by){
        name=n;
        dept=d;
        submittedBy=by;
    }

    public String getName(){
        return name;
    }

    public String getDept(){
        return dept;
    }

    public String getSubmittedBy(){
        return submittedBy;
    }

    public void setName(String n){
        name=n;
    }
    public void setDept(String d){
        dept=d;
    }

}
