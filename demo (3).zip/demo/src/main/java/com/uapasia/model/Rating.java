package com.uapasia.model;
public class Rating {
    private String professorName, comment, byUser;
    private int score;

    public Rating(){

    }

    public Rating(String prof,int s,String c,String by){
        professorName=prof;
        score=s; comment=c;
        byUser=by;
    }

    public String getProfessorName(){
        return professorName;
    }

    public int getScore(){
        return score;
    }

    public String getComment(){
        return comment;
    }

    public String getByUser(){
        return byUser;
    }

    public void setProfessorName(String prof){
        professorName=prof;
    }

    public void setScore(int s){
        score=s;
    }
    public void setComment(String c){}
}
