package com.uap.asia.bootstrap;

import com.uapasia.model.User;
import com.uapasia.repo.ContextStore;
import javax.servlet.*;

public class AppBootstrap implements ServletContextListener {
    @Override public void contextInitialized(ServletContextEvent sce) {
        ContextStore.init(sce.getServletContext());
    }
    @Override public void contextDestroyed(ServletContextEvent sce) {}
}
